<?php
  Class ia{
      public $columna;
      public $fila;

        public function randomPos(){

	         $this->columna=rand(0,3);
	         $this->	fila=rand(,3);
}


        public function getColumna()
    {

        return $columna;

    }
	     public function getFila()
    {
        return $fila ;
    }


		  public function setColumna($col)
		    {
		         $this->columna=$col;

		    }
			public function setFila($fil)
		    {

		        $this->fila=$fil ;
		    }
}
?>
